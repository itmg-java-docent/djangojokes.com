# djangojokes.com
Django Jokes Website
## Practice Site for Learning Django
I am using this site to learn. It is based on
[Django Jokes](https://www.djangojokes.com).